function cost = costFun(u)
% cost = costFun(u)
%
% Cost is the integral of torque-squared.

cost = u.^2; 

end