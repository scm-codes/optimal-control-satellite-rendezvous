# README  --  Pendulum Gradients

This example show how to compute the optimal swing-up trajectory for a simple pendulum.

It is also used to demonstrate how to construct analytic gradients for a trajectory optimization problem.

